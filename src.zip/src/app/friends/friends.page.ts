import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

import {AddContactModalPage} from '../add-contact-modal/add-contact-modal.page';

@Component({
  selector: 'app-friends',
  templateUrl: './friends.page.html',
  styleUrls: ['./friends.page.scss'],
})
export class FriendsPage implements OnInit {
  name:string;

  contacts = [{ name: 'brodie hueppauff',}, {name: 'fendord sentamara'}, {name: 'sylvanas windrunner'}]

  constructor(private modalController: ModalController) { }

  ngOnInit() {
  }
  // function to create add contact modal page
  async addFriend(){

    const modal = await this.modalController.create({
      component: AddContactModalPage,
      componentProps: { }
    });
    return await modal.present();
  }


}

